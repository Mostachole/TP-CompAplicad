history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamectl set-hostname TPServer
hostnamectl
cd /etc
ls
cd apt
nano sources.list
vim sources.list
lsb_release -a
cat /etc/debian_version
apt update
apt upgrade
apt autoremove
vim sources.list
vim souces.list
vim sources.lis
vim sources.list
cd /etc/apt/sources.list /etc/apt/sources.list.backup
cp  /etc/apt/sources.list /etc/apt/sources.list.backup
ls
vim sources.list.backup
vim sources.list
vim sources.list
apt update
apt upgrade
cat/etc/debian_version
cat /etc/apt/debian_version
cat /etc/debian_version
vim sources.list
apt update
apt full-upgrade
reboot
cd /etc
cd /apt
cd /apt
ls
cd apt
ls
vim sources.list.backup
cl
clear
cd ..
cd..
cd ..
cd /etc
cd apt
ls
cd ..
cd ssh
ls
cd ..
cd apt
ls
vim sources.list
cat /etc/network/interfaces
ip a
cd ..
ls
cd apt
vim sources.list
vim sources.list
clear
apt update
apt upgrade
apt full-upgrade
reboot
cd /etc
cd apt
ls
vim sources.list
apt-cache show apache2
apt update
apt upgrade
cd /root
cd var
cd /var
cd www
cd html
systemctl restart apache2
cd ..
cd ..
cd ..
cd /root
ls
cd Material_Adicional_TPVMCA
ls
cd /root 
ls
cd ..
ls
mysql -u root tp_ingenieria < /root/Material_Adicional_TPVMCA/db.sql
mysql -u root
cd /root
ls
cd Material_Adicional_TPVMCA
ls
mysql -u root tp_ingenieria < /root/Material_Adicional_TPVMCA/db.sql
mysql -u root
mysql -u root tp_compaplicada < /root/Material_Adicional_TPVMCA/db.sql
mysql -u root
apt update
apt install php libapache2-mod-php
apt install php-mysql
update
apt update
ip a
tal -n 20 /var/log/apache2/error.log
cd /var
cd www
cd htlm
ls
cd htlm
ls -a
cd /htlm
cd htlm
ls
ls -l
cd html
ls
vim index.php
mysql -u root
mysql -u root ingenieria < /root/Material_Adicional_TP_TPVMCA/db.sql
cd ..
cd ..
cd ..
ls
cd /root
ls
ls
pwd
cd ..
pwd
mysql -u root ingenieria < /root/Material_Adicional_TP_TPVMCA/db.sql
cd /root
ld
ls
cd Material_Adicional_TPVMCA
ls
mysql -u root ingenieria < db.sql
mysql -u root
mysql -u root ingenieria < db.sql
mysql -u root
mysql -u root ingenieria < db.sql
mysql -u root
mysql
mysql -u root
mysql -u root < db.sql
mysql -u root
systemctl restart apache2
mysql -u root
ip a
lsblk
lsblk
fdisk /dev/sdc
lsblk
cd /etc
vim fstab
vim fstab
mount -a
cp /root/Material_Adicional_TP_TPVMCA/index.php /www_dir/
cd .
ls
pwd
cd ,,
cd ..
ls
cd /var
ls
cd www
ls
cd htlm
cd html
ls
cp index.php /www_dir/
cp logo.png /www_dir/
vim index.php
cd..
cd ..
cd ..
cd ..
ls
cd www_dir
ls
pwd
chown -R www-data:www-data /www_dir/
chmod -R 755 /www_dir/
ls -a
pwd
cd ..
ls
ls -l
cd /etc
ls
cd apache2
ls
ls -l
ls -a
cd site-available
cd sites-available
ls
vim 000-dafault.conf
ls
vim 000-default.conf
vim 000-default.conf
cd ..
ls
vim apache2.conf
vim apache2.conf
systemctl restart apache2
cat /proc/partitions > /opt/particion
cd ..
cd opt
ls
ls
cd particion
cat /opt/particion
ls
ls -a
ls
cd ,,
cd ..
ls
cd /opt
ls
cd ..
cd etc
cd apache2
ls
cd sites-available
ls
vim 000-default.conf
cd,,
cd,,
cd ..
cd ..
cd ..
pwd
ls
cd /root
ls
cd /etc
cd apache2
vim apache2.conf
c ..
cd ,,
cd ..
cd ..
cd /opt
ls
cat particion
